This IPython notebook week5.ipynb does not require any additional
programs.
