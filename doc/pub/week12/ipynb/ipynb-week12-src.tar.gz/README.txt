This IPython notebook week12.ipynb does not require any additional
programs.
