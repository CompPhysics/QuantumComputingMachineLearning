This IPython notebook linalgebra.ipynb does not require any additional
programs.
